"""
╔══════════════════════════════════════════════════════════╗
║     🎬  FILE STORE BOT — NETLIFY SERVERLESS VERSION      ║
║     Uses Telegram Webhooks (no persistent process)       ║
║     Tech: Python + Telegram Bot API + MongoDB            ║
╚══════════════════════════════════════════════════════════╝

HOW IT WORKS:
  - Telegram sends every message/update to your Netlify URL
  - Netlify runs this function for each incoming update
  - No always-on server needed — truly serverless & free!
"""

import json
import os
import uuid
import hmac
import hashlib
from datetime import datetime, timedelta

import requests
from pymongo import MongoClient

# ─────────────────────────────────────────────────────────
#  🔧  CONFIG  (loaded from Netlify environment variables)
# ─────────────────────────────────────────────────────────
BOT_TOKEN    = os.environ["BOT_TOKEN"]
MONGO_URI    = os.environ["MONGO_URI"]
CHANNEL_ID   = int(os.environ["CHANNEL_ID"])
CHANNEL_LINK = os.environ["CHANNEL_LINK"]
ADMIN_ID     = int(os.environ["ADMIN_ID"])
BOT_USERNAME = os.environ["BOT_USERNAME"]
SECRET_TOKEN = os.environ.get("SECRET_TOKEN", "")     # Optional webhook security
AUTO_DEL_MIN = int(os.environ.get("AUTO_DEL_MIN", 10))

# Telegram Bot API base URL
API = f"https://api.telegram.org/bot{BOT_TOKEN}"

# ─────────────────────────────────────────────────────────
#  🗄️  DATABASE  (synchronous PyMongo — perfect for serverless)
# ─────────────────────────────────────────────────────────
_mongo_client = None

def get_db():
    """Lazy MongoDB connection — reused across warm Lambda invocations."""
    global _mongo_client
    if _mongo_client is None:
        _mongo_client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=5000)
    db = _mongo_client["filestore_bot"]
    return db


def add_user(user_id: int, username: str = None):
    db = get_db()
    db.users.update_one(
        {"user_id": user_id},
        {"$set": {"user_id": user_id, "username": username, "updated_at": datetime.utcnow()}},
        upsert=True,
    )


def get_total_users() -> int:
    return get_db().users.count_documents({})


def get_all_user_ids() -> list:
    return [d["user_id"] for d in get_db().users.find({}, {"user_id": 1})]


def store_video(file_id: str, key: str, caption: str):
    get_db().videos.insert_one({
        "key":        key,
        "file_id":    file_id,
        "caption":    caption or "",
        "created_at": datetime.utcnow(),
    })


def get_video(key: str):
    return get_db().videos.find_one({"key": key})


def schedule_delete(chat_id: int, message_id: int):
    """Store a pending delete record — cleaned up by the cleanup function."""
    delete_at = datetime.utcnow() + timedelta(minutes=AUTO_DEL_MIN)
    get_db().pending_deletes.insert_one({
        "chat_id":    chat_id,
        "message_id": message_id,
        "delete_at":  delete_at,
    })


# ─────────────────────────────────────────────────────────
#  📡  TELEGRAM API HELPERS
# ─────────────────────────────────────────────────────────
def tg(method: str, **kwargs) -> dict:
    """Make a Telegram Bot API call."""
    r = requests.post(f"{API}/{method}", json=kwargs, timeout=10)
    return r.json()


def send_message(chat_id: int, text: str, reply_markup=None, parse_mode="Markdown"):
    payload = {"chat_id": chat_id, "text": text, "parse_mode": parse_mode}
    if reply_markup:
        payload["reply_markup"] = reply_markup
    return tg("sendMessage", **payload)


def send_video(chat_id: int, file_id: str, caption: str):
    return tg("sendVideo",
              chat_id=chat_id,
              video=file_id,
              caption=caption,
              parse_mode="Markdown")


def answer_callback(callback_id: str):
    tg("answerCallbackQuery", callback_query_id=callback_id)


def edit_message(chat_id: int, message_id: int, text: str, reply_markup=None):
    payload = {"chat_id": chat_id, "message_id": message_id,
               "text": text, "parse_mode": "Markdown"}
    if reply_markup:
        payload["reply_markup"] = reply_markup
    tg("editMessageText", **payload)


def is_subscribed(user_id: int) -> bool:
    """Check if user is a member of the force-subscribe channel."""
    r = tg("getChatMember", chat_id=CHANNEL_ID, user_id=user_id)
    if not r.get("ok"):
        return False
    status = r["result"]["status"]
    return status not in ("left", "kicked")


# ─────────────────────────────────────────────────────────
#  ⌨️  INLINE KEYBOARDS
# ─────────────────────────────────────────────────────────
def fsub_keyboard(deep_link: str) -> dict:
    return {"inline_keyboard": [
        [{"text": "📢  Join Channel", "url": CHANNEL_LINK}],
        [{"text": "✅  I Joined — Try Again", "url": deep_link}],
    ]}


def start_keyboard() -> dict:
    return {"inline_keyboard": [
        [
            {"text": "📢  Channel", "url": CHANNEL_LINK},
            {"text": "🆘  Help",    "callback_data": "help"},
        ],
    ]}


def back_keyboard() -> dict:
    return {"inline_keyboard": [
        [{"text": "🔙  Back", "callback_data": "back_start"}],
    ]}


# ─────────────────────────────────────────────────────────
#  🎯  UPDATE HANDLERS
# ─────────────────────────────────────────────────────────

def handle_start(chat_id: int, user: dict, args: list):
    """Handle /start [deep_link_key]"""
    add_user(user["id"], user.get("username"))
    mention = f"[{user.get('first_name', 'there')}](tg://user?id={user['id']})"

    if len(args) > 1:
        # Deep link — user wants a specific video
        handle_video_request(chat_id, user["id"], args[1])
        return

    send_message(
        chat_id,
        f"👋 *Hello, {mention}!*\n\n"
        "🎬 Welcome to the *File Store Bot* — your premium video vault.\n\n"
        "📌 *How it works:*\n"
        "› An admin shares a private video link\n"
        "› You open the link in this bot\n"
        "› Join our channel to unlock the video\n"
        "› Enjoy your content! 🎉\n\n"
        "🔐 _All content is protected and auto-expires for copyright safety._",
        reply_markup=start_keyboard(),
    )


def handle_video_request(chat_id: int, user_id: int, key: str):
    """Core unlock logic — check FSUB then deliver video."""
    video_doc = get_video(key)
    deep_link = f"https://t.me/{BOT_USERNAME}?start={key}"

    if not video_doc:
        send_message(chat_id,
            "❌ *Invalid or Expired Link*\n\n"
            "_This link does not exist or has been removed._")
        return

    if not is_subscribed(user_id):
        send_message(
            chat_id,
            "🔒 *Access Denied!*\n\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "You must join our *official channel* to unlock this content.\n\n"
            "📢 *Step 1:* Click _Join Channel_ below\n"
            "✅ *Step 2:* Click _I Joined — Try Again_\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "🎬 _Your video is waiting for you!_",
            reply_markup=fsub_keyboard(deep_link),
        )
        return

    caption = (video_doc.get("caption") or "🎬 Here's your exclusive content!")
    caption += f"\n\n⚠️ _This video will auto-delete in {AUTO_DEL_MIN} minutes._"

    result = send_video(chat_id, video_doc["file_id"], caption)
    if result.get("ok"):
        msg_id = result["result"]["message_id"]
        schedule_delete(chat_id, msg_id)  # Stored for cleanup function


def handle_admin_video(chat_id: int, video: dict, caption: str):
    """Admin sent a video — generate and return unique share link."""
    file_id = video["file_id"]
    key     = uuid.uuid4().hex[:12]
    store_video(file_id, key, caption)

    deep_link = f"https://t.me/{BOT_USERNAME}?start={key}"
    send_message(
        chat_id,
        f"✅ *Video Stored Successfully!*\n\n"
        f"🔑 *Unique Key:* `{key}`\n\n"
        f"🔗 *Shareable Link:*\n"
        f"`{deep_link}`\n\n"
        f"📤 _Share this link with anyone._\n"
        f"⏱️ _Video auto-deletes {AUTO_DEL_MIN} min after viewing._",
    )


def handle_stats(chat_id: int):
    total_users  = get_total_users()
    total_videos = get_db().videos.count_documents({})
    pending_del  = get_db().pending_deletes.count_documents({})
    send_message(
        chat_id,
        "📊 *Bot Analytics*\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"👥 *Total Users:*     `{total_users:,}`\n"
        f"🎬 *Stored Videos:*   `{total_videos:,}`\n"
        f"🗑️ *Pending Deletes:* `{pending_del:,}`\n"
        f"⏱️ *Auto-Delete:*     `{AUTO_DEL_MIN} minutes`\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"🕒 _{datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}_",
    )


def handle_broadcast(chat_id: int, reply_msg: dict):
    """Broadcast the replied-to message to all users."""
    if not reply_msg:
        send_message(chat_id,
            "⚠️ *Usage:* Reply to any message with `/broadcast`\n"
            "_That message will be forwarded to all users._")
        return

    user_ids = get_all_user_ids()
    total    = len(user_ids)
    success  = 0
    failed   = 0

    for uid in user_ids:
        try:
            tg("copyMessage",
               chat_id=uid,
               from_chat_id=chat_id,
               message_id=reply_msg["message_id"])
            success += 1
        except Exception:
            failed += 1

    send_message(
        chat_id,
        f"✅ *Broadcast Complete!*\n\n"
        f"👥 *Total:*     `{total:,}`\n"
        f"✔️  *Delivered:* `{success:,}`\n"
        f"❌ *Failed:*    `{failed:,}`",
    )


def handle_callback(callback_query: dict):
    """Handle inline button presses."""
    data       = callback_query["data"]
    message    = callback_query["message"]
    chat_id    = message["chat"]["id"]
    message_id = message["message_id"]
    user       = callback_query["from"]
    answer_callback(callback_query["id"])

    if data == "help":
        edit_message(
            chat_id, message_id,
            "🆘 *Help & Info*\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "🔗 *Get content:* Use a share link from the admin\n"
            "📢 *Unlock:*      Join the required channel\n"
            "⚠️ *Auto-delete:* Videos expire after 10 minutes\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "*Admin Commands:*\n"
            "› Send a video → get a share link\n"
            "› `/stats`       → analytics dashboard\n"
            "› `/broadcast`   → message all users\n",
            reply_markup=back_keyboard(),
        )

    elif data == "back_start":
        mention = f"[{user.get('first_name', 'there')}](tg://user?id={user['id']})"
        edit_message(
            chat_id, message_id,
            f"👋 *Hello, {mention}!*\n\n"
            "🎬 Welcome to the *File Store Bot* — your premium video vault.\n\n"
            "📌 *How it works:*\n"
            "› An admin shares a private video link\n"
            "› You open the link in this bot\n"
            "› Join our channel to unlock the video\n"
            "› Enjoy your content! 🎉\n\n"
            "🔐 _All content is protected and auto-expires for copyright safety._",
            reply_markup=start_keyboard(),
        )


# ─────────────────────────────────────────────────────────
#  🚀  NETLIFY FUNCTION ENTRY POINT
# ─────────────────────────────────────────────────────────
def handler(event, context):
    """
    Netlify calls this for every incoming Telegram update.
    Telegram sends a POST request with the update JSON in the body.
    """

    # ── Security: verify Telegram secret token header ──
    if SECRET_TOKEN:
        incoming = event.get("headers", {}).get("x-telegram-bot-api-secret-token", "")
        if incoming != SECRET_TOKEN:
            return {"statusCode": 403, "body": "Forbidden"}

    # ── Parse the incoming Telegram update ──
    try:
        update = json.loads(event.get("body") or "{}")
    except json.JSONDecodeError:
        return {"statusCode": 400, "body": "Bad Request"}

    try:
        # ── CALLBACK QUERY (inline button press) ──
        if "callback_query" in update:
            handle_callback(update["callback_query"])

        # ── MESSAGE ──
        elif "message" in update:
            msg     = update["message"]
            chat_id = msg["chat"]["id"]
            user    = msg.get("from", {})
            user_id = user.get("id")
            text    = msg.get("text", "")

            # /start command
            if text.startswith("/start"):
                args = text.split()
                handle_start(chat_id, user, args)

            # /stats — admin only
            elif text == "/stats" and user_id == ADMIN_ID:
                handle_stats(chat_id)

            # /broadcast — admin only, must reply to a message
            elif text == "/broadcast" and user_id == ADMIN_ID:
                handle_broadcast(chat_id, msg.get("reply_to_message"))

            # Admin sends a video
            elif "video" in msg and user_id == ADMIN_ID:
                handle_admin_video(chat_id, msg["video"], msg.get("caption", ""))

    except Exception as e:
        # Never crash — always return 200 to Telegram or it will retry endlessly
        print(f"Handler error: {e}")

    # Always return 200 OK to Telegram
    return {"statusCode": 200, "body": "ok"}
