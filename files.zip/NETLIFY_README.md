# 🎬 File Store Bot — Netlify Edition

Telegram File Store & Video Unlock Bot running on **Netlify Serverless Functions**.
100% free, no card required, no always-on server needed.

---

## 🏗️ Project Structure

```
netlify_bot/
├── netlify/
│   └── functions/
│       ├── webhook.py        ← Main bot logic (handles all Telegram updates)
│       ├── cleanup.py        ← Auto-delete scheduler (runs every 5 min)
│       └── requirements.txt  ← Python dependencies for functions
├── public/
│   └── index.html            ← Required placeholder page for Netlify
├── netlify.toml              ← Netlify config (routes + schedule)
├── setup_webhook.py          ← Run once to register webhook with Telegram
├── .env.example              ← Config template
└── .gitignore
```

---

## ⚙️ How It Works (Webhook vs Polling)

| Old bot (Pyrogram) | This bot (Webhook) |
|---|---|
| Runs 24/7, polls Telegram | Sleeps until a message arrives |
| Needs a server | Runs on Netlify for free |
| Uses MTProto (complex) | Uses Bot API (simple HTTP) |
| Always-on process | Serverless function |

When a user messages your bot, Telegram instantly POSTs the update
to your Netlify URL. Netlify wakes up `webhook.py` for ~1 second,
processes it, and sleeps again. You only pay for what you use —
which on the free tier is always zero.

---

## 🚀 Deployment Steps

### 1. Push to GitHub

```bash
git init
git add .
git commit -m "Netlify bot"
git branch -M main
git remote add origin https://github.com/YOU/REPO.git
git push -u origin main
```

### 2. Deploy on Netlify (free, no card)

1. Go to **netlify.com** → Sign up with GitHub
2. Click **"Add new site"** → **"Import an existing project"**
3. Choose **GitHub** → select your repo
4. Build settings (leave as-is, netlify.toml handles it)
5. Click **"Deploy site"**

### 3. Add Environment Variables

In Netlify dashboard:
**Site Settings → Environment Variables → Add variable**

Add each of these:

| Key | Value |
|---|---|
| `BOT_TOKEN` | From @BotFather |
| `MONGO_URI` | MongoDB Atlas connection string |
| `CHANNEL_ID` | e.g. `-1001234567890` |
| `CHANNEL_LINK` | `https://t.me/yourchannel` |
| `ADMIN_ID` | Your Telegram user ID |
| `BOT_USERNAME` | Your bot's username (no @) |
| `AUTO_DEL_MIN` | `10` |
| `SECRET_TOKEN` | Any random string (for security) |

After adding, trigger a **redeploy** (Deploys tab → "Trigger deploy").

### 4. Register the Webhook (ONE TIME ONLY)

Run this locally after deployment:

```bash
pip install requests python-dotenv
python setup_webhook.py
```

Enter your Netlify URL when prompted (e.g. `https://yoursite.netlify.app`).

That's it — your bot is live!

---

## ✅ Testing

1. Open Telegram → find your bot → send `/start`
2. Admin: send a video to the bot → copy the link it returns
3. Open the link → if not subscribed, see the Access Denied screen
4. Join the channel → click "Try Again" → video unlocks

---

## 🔒 Security Checklist

- [x] `.env` never committed (in `.gitignore`)
- [x] `SECRET_TOKEN` verifies requests are from Telegram, not random people
- [x] Admin commands restricted by `ADMIN_ID` check
- [x] FSUB check on every video request

---

## ⚠️ Netlify Free Tier Limits

| Limit | Free Allowance |
|---|---|
| Function invocations | 125,000 / month |
| Function runtime | 10 seconds max per call |
| Bandwidth | 100 GB / month |

For a typical bot with a few hundred users, you'll never hit these limits.
The `/broadcast` command may timeout if you have 1000+ users — split it into batches for large audiences.

---

## 📄 License

MIT
